<div class="profile_info"><img src="{{getStudentImage($query->image)}}" alt="{{$query->name}}"></div>
