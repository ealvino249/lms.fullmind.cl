<?php
return [
    'organization' => 'organization',
    'Organization' => 'Organization',
];
