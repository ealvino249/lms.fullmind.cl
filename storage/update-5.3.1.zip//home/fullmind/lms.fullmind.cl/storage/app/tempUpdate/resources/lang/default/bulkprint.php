<?php
return [
    'BulkPrint' => 'BulkPrint',
    'No Student Found' => 'No Student Found'
];
