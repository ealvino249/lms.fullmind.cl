<?php

namespace Modules\Setting\Entities;

use App\User;
use Illuminate\Database\Eloquent\Model;

class UserGamificationPoint extends Model
{
    protected $guarded = ['id'];


}
