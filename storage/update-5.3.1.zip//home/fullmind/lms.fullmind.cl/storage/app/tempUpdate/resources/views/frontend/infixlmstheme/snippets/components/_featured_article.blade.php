<div data-type="container"
     data-preview="{{!function_exists('themeAsset')?'':themeAsset('img/snippets/preview/featured_article.png')}}"
     data-aoraeditor-title="Featured Article" data-aoraeditor-categories="Text;Heading;Photo">
    <div class="row">
        <div class="col-sm-6" data-type="container-content">
            <div data-type="component-text">
                <div class="photo-panel" style="text-align: center;">
                    <img
                        src="{{!function_exists('themeAsset')?'':themeAsset('img/snippets/img/sydney_australia_squared.jpg')}}"
                        width="100%" height="" style="display: inline-block; height: 334px; width: 334px;"
                        class="img-responsive img-circle">
                </div>
            </div>
        </div>
        <div class="col-sm-6" data-type="container-content">
            <div data-type="component-text">
                <h3>Lorem ipsum</h3>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Sequi molestias eius quaerat, adipisci
                    ratione aliquid eum explicabo illum temporibus? Optio facilis eveniet quam, impedit eos architecto
                    sequi dolorum illo facere, consequatur sit voluptatibus sunt eius ad officia corrupti modi quia
                    minima voluptas vero. Minus, maxime! Lorem ipsum dolor sit amet, consectetur adipisicing elit. Sequi
                    molestias eius quaerat, adipisci ratione aliquid eum explicabo.</p>
            </div>
        </div>
    </div>
</div>
