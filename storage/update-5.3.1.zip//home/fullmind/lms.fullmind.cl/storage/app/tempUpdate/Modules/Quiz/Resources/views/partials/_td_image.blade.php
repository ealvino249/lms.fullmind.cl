<img style="max-width: 150px;" src="{{asset($query->image)}}" alt="">
