<?php

namespace Modules\Setting\Entities;

use Illuminate\Database\Eloquent\Model;

class UserLevelHistory extends Model
{
    protected $guarded = ['id'];
}
