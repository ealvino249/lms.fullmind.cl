<?php

namespace Modules\Setting\Entities;

use Illuminate\Database\Eloquent\Model;

class Badge extends Model
{
    protected $guarded = ['id'];
}
