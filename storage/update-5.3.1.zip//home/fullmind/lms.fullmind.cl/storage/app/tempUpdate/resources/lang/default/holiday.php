<?php

return [
    'Holidays of' => 'Holidays of',
    'Days' => 'Days',
    'Purpose' => 'Purpose',
    'Date' => 'Date',
    'Holiday Name' => 'Holiday Name',
    'Select Type' => 'Select Type',
    'Single Day' => 'Single Day',
    'Multiple Day' => 'Multiple Day',
    'Start Date' => 'Start Date',
    'End Date' => 'End Date',
    'Year' => 'Year',
    'Holiday Setup' => 'Holiday Setup',
    'Add New Year' => 'Add New Year',
    'Holiday Copy From' => 'Holiday Copy From',
    'Select Year' => 'Select Year'
];

