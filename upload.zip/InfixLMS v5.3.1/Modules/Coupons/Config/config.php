<?php

return [
    'name' => 'Coupons'
];
