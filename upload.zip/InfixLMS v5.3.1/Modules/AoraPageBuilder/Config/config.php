<?php

return [
    'name' => 'AoraPageBuilder'
];
