<?php

return [
    'name' => 'FooterSetting'
];
