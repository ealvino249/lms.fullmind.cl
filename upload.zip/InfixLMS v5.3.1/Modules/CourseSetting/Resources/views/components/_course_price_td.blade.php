<span>{{$query->discount_price != null?getPriceFormat($query->discount_price):getPriceFormat($query->price)}}</span>
